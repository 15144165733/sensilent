import { normalizeLocale, type LocaleCode } from "@/lib/i18n/locale";

export const LOCALE_STORAGE_KEY = "eazo-app.locale.v1";

export type LocalePreference = LocaleCode | "system";

export function detectSystemLocale(): LocaleCode {
  const browserLanguages =
    typeof navigator !== "undefined"
      ? [navigator.language, ...(navigator.languages ?? [])]
      : [];
  for (const language of browserLanguages) {
    const locale = normalizeLocale(language);
    if (locale) return locale;
  }
  return "zh-CN";
}

export function parseLocalePreference(raw: string | null | undefined): LocalePreference {
  if (!raw) return "zh-CN";
  if (raw === "system") return "system";
  return normalizeLocale(raw) ?? "zh-CN";
}

export function resolveLocalePreference(preference: LocalePreference): LocaleCode {
  return preference === "system" ? detectSystemLocale() : preference;
}

function getBrowserStorage(): Storage | null {
  if (typeof localStorage === "undefined") return null;
  return localStorage;
}

/** Read preference from localStorage (client only). 默认中文。 */
export function getLocalePreference(): LocalePreference {
  const storage = getBrowserStorage();
  if (!storage) return "zh-CN";
  return parseLocalePreference(storage.getItem(LOCALE_STORAGE_KEY));
}

export function persistLocalePreference(preference: LocalePreference): void {
  getBrowserStorage()?.setItem(LOCALE_STORAGE_KEY, preference);
  if (typeof document !== "undefined") {
    document.cookie = `${LOCALE_STORAGE_KEY}=${encodeURIComponent(preference)}; path=/; max-age=${60 * 60 * 24 * 365}; SameSite=Lax`;
  }
}
