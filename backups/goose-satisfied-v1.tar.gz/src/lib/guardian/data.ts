// WaveGuard 演示数据：对齐仓库真实 5 场景剧本 + 完整建档字段 + 守护时间线
// 文案以 i18n key 呈现，页面用 t() 翻译，切换语言时不混杂。
import type {
  ScenarioMeta,
  Scenario,
  TimelineEvent,
  ElderProfile,
} from "./types";

/** 真实 5 场景（对齐 waveguard/replay/scenarios 剧本：段落 pattern + 运动带 + 呼吸带） */
export const SCENARIOS: Record<Scenario, ScenarioMeta> = {
  demo_rest: {
    key: "demo_rest",
    emoji: "🛋️",
    labelKey: "guardian.scenario.demo_rest",
    descKey: "guardian.scenario.demo_rest_desc",
    zone: "safe",
    segments: [
      { labelKey: "guardian.seg.demo_rest.0", durationS: 15, pattern: "active", low: 0.35, high: 0.55, brLow: 14, brHigh: 17, zone: "safe" },
      { labelKey: "guardian.seg.demo_rest.1", durationS: 5, pattern: "active", low: 0.3, high: 0.5, brLow: 14, brHigh: 16, zone: "safe" },
      { labelKey: "guardian.seg.demo_rest.2", durationS: 20, pattern: "still", low: 0.02, high: 0.05, brLow: 13, brHigh: 16, zone: "safe" },
      { labelKey: "guardian.seg.demo_rest.3", durationS: 20, pattern: "still", low: 0.02, high: 0.05, brLow: 13, brHigh: 15, zone: "safe" },
    ],
  },
  demo_active: {
    key: "demo_active",
    emoji: "🧹",
    labelKey: "guardian.scenario.demo_active",
    descKey: "guardian.scenario.demo_active_desc",
    zone: "safe",
    segments: [
      { labelKey: "guardian.seg.demo_active.0", durationS: 20, pattern: "active", low: 0.35, high: 0.6, brLow: 14, brHigh: 18, zone: "safe" },
      { labelKey: "guardian.seg.demo_active.1", durationS: 10, pattern: "still", low: 0.02, high: 0.05, brLow: 13, brHigh: 16, zone: "safe" },
      { labelKey: "guardian.seg.demo_active.2", durationS: 20, pattern: "active", low: 0.35, high: 0.55, brLow: 14, brHigh: 17, zone: "safe" },
      { labelKey: "guardian.seg.demo_active.3", durationS: 10, pattern: "active", low: 0.3, high: 0.5, brLow: 14, brHigh: 16, zone: "safe" },
    ],
  },
  demo_fall_still: {
    key: "demo_fall_still",
    emoji: "🩹",
    labelKey: "guardian.scenario.demo_fall_still",
    descKey: "guardian.scenario.demo_fall_still_desc",
    zone: "alert",
    segments: [
      { labelKey: "guardian.seg.demo_fall_still.0", durationS: 15, pattern: "still", low: 0.02, high: 0.05, brLow: 12, brHigh: 15, zone: "safe" },
      { labelKey: "guardian.seg.demo_fall_still.1", durationS: 3, pattern: "spike", low: 0.95, high: 1.0, brLow: 16, brHigh: 20, zone: "watch" },
      { labelKey: "guardian.seg.demo_fall_still.2", durationS: 12, pattern: "still", low: 0.02, high: 0.045, brLow: 22, brHigh: 26, brState: "elevated", zone: "alert" },
      { labelKey: "guardian.seg.demo_fall_still.3", durationS: 10, pattern: "still", low: 0.03, high: 0.08, brLow: 16, brHigh: 19, zone: "watch" },
      { labelKey: "guardian.seg.demo_fall_still.4", durationS: 20, pattern: "still", low: 0.02, high: 0.05, brLow: 13, brHigh: 16, zone: "safe" },
    ],
  },
  demo_fall_moving: {
    key: "demo_fall_moving",
    emoji: "🚨",
    labelKey: "guardian.scenario.demo_fall_moving",
    descKey: "guardian.scenario.demo_fall_moving_desc",
    zone: "alert",
    segments: [
      { labelKey: "guardian.seg.demo_fall_moving.0", durationS: 12, pattern: "active", low: 0.35, high: 0.55, brLow: 14, brHigh: 17, zone: "safe" },
      { labelKey: "guardian.seg.demo_fall_moving.1", durationS: 3, pattern: "spike", low: 0.95, high: 1.0, brLow: 16, brHigh: 20, zone: "watch" },
      { labelKey: "guardian.seg.demo_fall_moving.2", durationS: 12, pattern: "still", low: 0.02, high: 0.045, brLow: 9, brHigh: 11, brState: "irregular", zone: "alert" },
      { labelKey: "guardian.seg.demo_fall_moving.3", durationS: 8, pattern: "still", low: 0.02, high: 0.045, brLow: 9, brHigh: 11, brState: "irregular", zone: "alert" },
      { labelKey: "guardian.seg.demo_fall_moving.4", durationS: 22, pattern: "still", low: 0.02, high: 0.045, brLow: 9, brHigh: 11, brState: "irregular", zone: "alert" },
    ],
  },
  demo_fall_noresponse: {
    key: "demo_fall_noresponse",
    emoji: "🆘",
    labelKey: "guardian.scenario.demo_fall_noresponse",
    descKey: "guardian.scenario.demo_fall_noresponse_desc",
    zone: "alert",
    segments: [
      { labelKey: "guardian.seg.demo_fall_noresponse.0", durationS: 10, pattern: "active", low: 0.35, high: 0.55, brLow: 14, brHigh: 17, zone: "safe" },
      { labelKey: "guardian.seg.demo_fall_noresponse.1", durationS: 3, pattern: "spike", low: 0.95, high: 1.0, brLow: 16, brHigh: 20, zone: "watch" },
      { labelKey: "guardian.seg.demo_fall_noresponse.2", durationS: 12, pattern: "still", low: 0.02, high: 0.045, brLow: 22, brHigh: 26, brState: "elevated", zone: "alert" },
      { labelKey: "guardian.seg.demo_fall_noresponse.3", durationS: 18, pattern: "still", low: 0.02, high: 0.045, brLow: 22, brHigh: 26, brState: "elevated", zone: "alert" },
      { labelKey: "guardian.seg.demo_fall_noresponse.4", durationS: 12, pattern: "still", low: 0.02, high: 0.045, brLow: 22, brHigh: 26, brState: "elevated", zone: "alert" },
      { labelKey: "guardian.seg.demo_fall_noresponse.5", durationS: 30, pattern: "still", low: 0.02, high: 0.045, brLow: 22, brHigh: 26, brState: "elevated", zone: "alert" },
    ],
  },
};

export const SCENARIO_ORDER: Scenario[] = [
  "demo_rest",
  "demo_active",
  "demo_fall_still",
  "demo_fall_moving",
  "demo_fall_noresponse",
];

/** 首页守护时间线（平安态） */
export const TIMELINE: TimelineEvent[] = [
  { id: "wake", time: "08:12", emoji: "🌤️", titleKey: "guardian.timeline.wake", descKey: "guardian.timeline.wake_desc", detailKey: "guardian.timeline.wake_detail", tagKey: "guardian.timeline.tag.safe" },
  { id: "meal", time: "09:05", emoji: "🥣", titleKey: "guardian.timeline.meal", descKey: "guardian.timeline.meal_desc", detailKey: "guardian.timeline.meal_detail", tagKey: "guardian.timeline.tag.normal" },
  { id: "rest", time: "12:30", emoji: "🍵", titleKey: "guardian.timeline.rest", descKey: "guardian.timeline.rest_desc", detailKey: "guardian.timeline.rest_detail", tagKey: "guardian.timeline.tag.stable" },
  { id: "walk", time: "15:06", emoji: "🫧", titleKey: "guardian.timeline.walk", descKey: "guardian.timeline.walk_desc", detailKey: "guardian.timeline.walk_detail", tagKey: "guardian.timeline.tag.normal" },
];

/** 预填「奶奶」完整档案（评审可就地微调） */
export const DEFAULT_PROFILE: ElderProfile = {
  name: "李桂兰",
  age: 78,
  weightKg: 58,
  relationshipKey: "grandma",
  locationKey: "living_room",
  address: "杭州市西湖区文一西路 12 号 3 单元 502",
  healthStatusKey: "chronic_stable",
  diseaseKeys: ["hypertension", "diabetes"],
  fallCount: 1,
  syncopeCount: 0,
  familySuddenCardiacDeath: false,
  wakeTime: "06:30",
  sleepTime: "21:30",
  elderPhone: "138 0000 1111",
  contacts: [
    { id: "c1", rank: 1, name: "李桂兰", phone: "13800001111", relationshipKey: "guardian.contactRel.self" },
    { id: "c2", rank: 2, name: "李安", phone: "13900002222", relationshipKey: "guardian.contactRel.daughter" },
    { id: "c3", rank: 3, name: "王秀兰", phone: "13700003333", relationshipKey: "guardian.contactRel.neighbor" },
    { id: "c4", rank: 4, name: "120", phone: "120", relationshipKey: "guardian.contactRel.ems" },
  ],
};

/** 健康状况单选项（对齐仓库 HEALTH_STATUS_MAP） */
export const HEALTH_STATUS_KEYS = [
  "good",
  "chronic_stable",
  "mobility_limited",
  "frail",
  "post_surgery",
  "care_needed",
] as const;

/** 病史多选项（对齐仓库 DISEASE_MAP） */
export const DISEASE_KEYS = [
  "heart",
  "stroke",
  "epilepsy",
  "diabetes",
  "parkinson",
  "alzheimer",
  "hypertension",
  "anemia",
] as const;

/** 联系人关系预设（编辑时从中选择，避免中英混杂） */
export const CONTACT_REL_KEYS = [
  "self",
  "daughter",
  "son",
  "spouse",
  "neighbor",
  "caregiver",
  "ems",
] as const;

export const ZONE_META: Record<string, { color: string; bg: string }> = {
  safe: { color: "#5b8b76", bg: "#bfd9cd" },
  watch: { color: "#c47a2f", bg: "#f4d9b0" },
  alert: { color: "#ffffff", bg: "#d8584d" },
};

/** 场景总时长（秒） */
export function scenarioDuration(meta: ScenarioMeta): number {
  return meta.segments.reduce((s, seg) => s + seg.durationS, 0);
}

/** 依据已播放秒数取当前段落索引 */
export function segmentAt(meta: ScenarioMeta, elapsedS: number): number {
  const total = scenarioDuration(meta);
  let t = total > 0 ? elapsedS % total : 0;
  for (let i = 0; i < meta.segments.length; i++) {
    if (t < meta.segments[i].durationS) return i;
    t -= meta.segments[i].durationS;
  }
  return meta.segments.length - 1;
}
