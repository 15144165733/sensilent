"use client";

// 场景回放：按真实剧本段落随时间推进，输出当前段落与呼吸/活动读数。
import { useEffect, useRef, useState } from "react";
import type { ScenarioMeta, ScenarioSegment } from "@/lib/guardian/types";
import { scenarioDuration, segmentAt } from "@/lib/guardian/data";

export interface PlaybackState {
  elapsed: number;
  segIndex: number;
  segment: ScenarioSegment;
  segProgress: number;
  breathingRate: number;
  breathingState: string;
  activity: number;
}

function deriveBreathState(seg: ScenarioSegment): string {
  if (seg.brState) return seg.brState;
  const mid = (seg.brLow + seg.brHigh) / 2;
  if (mid < 3) return "lost";
  if (mid < 8) return "shallow";
  if (mid < 12) return "irregular";
  if (mid > 20) return "elevated";
  return "normal";
}

/** 切换场景时通过 startRef 归零，reduced-motion 时冻结在起始段。 */
export function useScenarioPlayback(meta: ScenarioMeta): PlaybackState {
  const [elapsed, setElapsed] = useState(0);
  const startRef = useRef<number>(0);

  useEffect(() => {
    // 场景切换：重置起点与初值（在副作用外部时间线，不触发级联）
    startRef.current = Date.now();
    const reduced =
      typeof window !== "undefined" &&
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    const total = scenarioDuration(meta);
    if (reduced || total <= 0) {
      return;
    }
    const id = setInterval(() => {
      const e = Math.floor((Date.now() - startRef.current) / 1000) % total;
      setElapsed(e);
    }, 1000);
    return () => clearInterval(id);
  }, [meta]);

  const segIndex = segmentAt(meta, elapsed);
  const segment = meta.segments[segIndex];

  let before = 0;
  for (let i = 0; i < segIndex; i++) before += meta.segments[i].durationS;
  const segProgress = segment.durationS > 0 ? (elapsed - before) / segment.durationS : 0;

  const breathingRate = Math.round((segment.brLow + segment.brHigh) / 2);
  const breathingState = deriveBreathState(segment);
  const activity = Math.round(((segment.low + segment.high) / 2) * 100);

  return { elapsed, segIndex, segment, segProgress, breathingRate, breathingState, activity };
}
