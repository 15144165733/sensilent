// WaveGuard 子女端演示 · 领域类型与场景语义（对齐仓库真实硬件/场景脚本）
// 文案通过 i18n key 呈现，避免中英混杂；专有名词（姓名/电话/住址）作为数据保留。

/** 语义三态 → 平安 / 注意 / 告警 */
export type StatusZone = "safe" | "watch" | "alert";

/** 呼吸状态映射（对齐 edge：normal/elevated/irregular/shallow/lost） */
export type BreathingState = "normal" | "elevated" | "irregular" | "shallow" | "lost";

/** 波形段落模式（对齐 replay/scenarios：still 静止 / active 活动 / spike 剧烈形变） */
export type SegmentPattern = "still" | "active" | "spike";

/** 演示场景 key（对齐仓库 5 个 demo 剧本） */
export type Scenario =
  | "demo_rest"
  | "demo_active"
  | "demo_fall_still"
  | "demo_fall_moving"
  | "demo_fall_noresponse";

/** 单个剧本段落：运动幅度带 [low,high]，呼吸频率带 [brLow,brHigh]，可显式指定呼吸态 */
export interface ScenarioSegment {
  /** i18n key：guardian.seg.<scenario>.<index> */
  labelKey: string;
  durationS: number;
  pattern: SegmentPattern;
  low: number;
  high: number;
  brLow: number;
  brHigh: number;
  brState?: BreathingState;
  /** 该段落语义状态（用于三态与颜色） */
  zone: StatusZone;
}

export interface ScenarioMeta {
  key: Scenario;
  emoji: string;
  /** i18n：guardian.scenario.<key> / <key>_desc */
  labelKey: string;
  descKey: string;
  /** 场景整体语义（跌倒类为 alert） */
  zone: StatusZone;
  segments: ScenarioSegment[];
}

export interface TimelineEvent {
  id: string;
  time: string;
  emoji: string;
  titleKey: string;
  descKey: string;
  detailKey: string;
  tagKey: string;
}

export interface EmergencyContact {
  id: string;
  rank: number;
  /** 联系人姓名 — 自由文本（专有名词），用户可编辑 */
  name: string;
  phone: string;
  /** 关系 i18n key（从预设选择，如 guardian.contactRel.self） */
  relationshipKey: string;
}

/** 完整建档字段（对齐仓库 ProfileData 信息收集模块） */
export interface ElderProfile {
  name: string; // 专有名
  age: number;
  weightKg: number;
  relationshipKey: string; // guardian.relationship.<x>
  locationKey: string; // guardian.location.<x>
  address: string;
  healthStatusKey: string; // guardian.health.<x>（单选）
  diseaseKeys: string[]; // guardian.disease.<x>（多选）
  /** 跌倒史次数（近一年） */
  fallCount: number;
  /** 晕厥史次数 */
  syncopeCount: number;
  /** 家族心源性猝死史 */
  familySuddenCardiacDeath: boolean;
  wakeTime: string;
  sleepTime: string;
  elderPhone: string;
  contacts: EmergencyContact[];
}
