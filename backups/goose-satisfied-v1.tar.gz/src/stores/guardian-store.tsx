"use client";

// WaveGuard 演示会话状态：当前场景 + 档案（就地微调） + 告警确认。
// 演示版不落库，状态存于内存并同步 sessionStorage，刷新保留本次体验。
import {
  createContext,
  useContext,
  useState,
  useCallback,
  type ReactNode,
} from "react";
import type { Scenario, ElderProfile } from "@/lib/guardian/types";
import { DEFAULT_PROFILE, SCENARIOS } from "@/lib/guardian/data";

interface GuardianState {
  scenario: Scenario;
  setScenario: (s: Scenario) => void;
  profile: ElderProfile;
  updateProfile: (patch: Partial<ElderProfile>) => void;
  alertAcknowledged: boolean;
  acknowledgeAlert: () => void;
  resetAlert: () => void;
  /** 一键还原演示数据到初始状态（清空本地存储） */
  resetDemo: () => void;
}

const GuardianContext = createContext<GuardianState | null>(null);

// 存储键带版本号：升级即可让旧的、被操作乱掉的本地数据自动作废。
const PROFILE_KEY = "wg_profile_v2";
const SCENARIO_KEY = "wg_scenario_v2";

function readProfile(): ElderProfile {
  if (typeof window === "undefined") return DEFAULT_PROFILE;
  try {
    const p = window.sessionStorage.getItem(PROFILE_KEY);
    // 与默认合并，容忍新增字段
    return p ? { ...DEFAULT_PROFILE, ...(JSON.parse(p) as ElderProfile) } : DEFAULT_PROFILE;
  } catch {
    return DEFAULT_PROFILE;
  }
}

function readScenario(): Scenario {
  if (typeof window === "undefined") return "demo_rest";
  try {
    const s = window.sessionStorage.getItem(SCENARIO_KEY) as Scenario | null;
    return s && SCENARIOS[s] ? s : "demo_rest";
  } catch {
    return "demo_rest";
  }
}

export function GuardianProvider({ children }: { children: ReactNode }) {
  const [scenario, setScenarioState] = useState<Scenario>(readScenario);
  const [profile, setProfile] = useState<ElderProfile>(readProfile);
  const [alertAcknowledged, setAlertAcknowledged] = useState(false);

  const setScenario = useCallback((s: Scenario) => {
    setScenarioState(s);
    if (SCENARIOS[s]?.zone === "alert") setAlertAcknowledged(false);
    try {
      sessionStorage.setItem(SCENARIO_KEY, s);
    } catch {
      /* 忽略 */
    }
  }, []);

  const updateProfile = useCallback((patch: Partial<ElderProfile>) => {
    setProfile((prev) => {
      const next = { ...prev, ...patch };
      try {
        sessionStorage.setItem(PROFILE_KEY, JSON.stringify(next));
      } catch {
        /* 忽略 */
      }
      return next;
    });
  }, []);

  const acknowledgeAlert = useCallback(() => {
    setAlertAcknowledged(true);
    setScenarioState("demo_rest");
    try {
      sessionStorage.setItem(SCENARIO_KEY, "demo_rest");
    } catch {
      /* 忽略 */
    }
  }, []);

  const resetAlert = useCallback(() => setAlertAcknowledged(false), []);

  const resetDemo = useCallback(() => {
    try {
      sessionStorage.removeItem(PROFILE_KEY);
      sessionStorage.removeItem(SCENARIO_KEY);
    } catch {
      /* 忽略 */
    }
    setProfile(DEFAULT_PROFILE);
    setScenarioState("demo_rest");
    setAlertAcknowledged(false);
  }, []);

  return (
    <GuardianContext.Provider
      value={{
        scenario,
        setScenario,
        profile,
        updateProfile,
        alertAcknowledged,
        acknowledgeAlert,
        resetAlert,
        resetDemo,
      }}
    >
      {children}
    </GuardianContext.Provider>
  );
}

export function useGuardian(): GuardianState {
  const ctx = useContext(GuardianContext);
  if (!ctx) throw new Error("useGuardian must be used within GuardianProvider");
  return ctx;
}

/** 触发手机震动（不支持时静默） */
export function vibrate(pattern: number | number[]) {
  try {
    if (typeof navigator !== "undefined" && "vibrate" in navigator) {
      navigator.vibrate(pattern);
    }
  } catch {
    /* 忽略 */
  }
}
