"use client";

// 平安日常首页：软糖状态徽章 + 奶奶状态卡 + 守护时间线；跌倒态显示告警横幅
import { useState } from "react";
import Link from "next/link";
import { useTranslation } from "react-i18next";
import { AppShell } from "@/components/guardian/app-shell";
import { useGuardian } from "@/stores/guardian-store";
import { SCENARIOS, TIMELINE } from "@/lib/guardian/data";
import { useScenarioPlayback } from "@/lib/guardian/use-scenario-playback";
import { ChevronRight, AlertTriangle, UserRound, Sunrise, Utensils, Coffee, Footprints, type LucideIcon } from "lucide-react";
import { GooseMark } from "@/components/guardian/brand-mark";

const TIMELINE_ICON: Record<string, LucideIcon> = {
  wake: Sunrise,
  meal: Utensils,
  rest: Coffee,
  walk: Footprints,
};

export default function DailyPage() {
  const { scenario, profile } = useGuardian();
  const { t } = useTranslation();
  const meta = SCENARIOS[scenario];
  const play = useScenarioPlayback(meta);
  const isAlert = play.segment.zone === "alert";
  const [openRow, setOpenRow] = useState<string | null>(null);
  const who = t(`guardian.relationship.${profile.relationshipKey}`);
  const loc = t(`guardian.location.${profile.locationKey}`);

  return (
    <AppShell gradient>
      {/* 品牌条 */}
      <header data-el="daily-brand" className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2 text-lg font-extrabold" style={{ color: "var(--dz-ink)" }}>
          <span className="grid h-8 w-8 place-items-center rounded-[10px] text-white" style={{ background: "var(--dz-orange)" }}>
            <GooseMark size={18} />
          </span>
          <span>{t("guardian.brand")}</span>
        </div>
        <span className="flex items-center gap-1.5 text-xs font-semibold" style={{ color: "var(--dz-ok)" }}>
          <span className="h-2 w-2 rounded-full" style={{ background: "var(--dz-ok)" }} />
          {t("guardian.online")}
        </span>
      </header>

      {/* 跌倒态告警横幅 */}
      {isAlert && (
        <Link
          href="/alert"
          data-el="daily-alert-banner"
          className="mb-4 flex items-center gap-3 rounded-[16px] p-4 text-white transition-transform active:scale-[.98]"
          style={{ background: "var(--dz-alert)" }}
        >
          <AlertTriangle size={24} />
          <div className="flex-1">
            <div className="font-bold">{t("guardian.daily.banner", { who })}</div>
            <div className="text-[13px] opacity-90">{t("guardian.daily.bannerSub")}</div>
          </div>
          <ChevronRight size={22} />
        </Link>
      )}

      {/* 状态大卡：利落矩形 */}
      <article
        data-el="daily-status-card"
        className="overflow-hidden rounded-[18px] p-6 text-center"
        style={{
          background: isAlert ? "rgba(224,69,42,.06)" : "#f2f8f1",
          border: `1px solid ${isAlert ? "rgba(224,69,42,.18)" : "#e4efe2"}`,
        }}
      >
        <div
          className="mx-auto grid h-16 w-16 place-items-center rounded-full text-2xl font-extrabold text-white"
          style={{ background: isAlert ? "var(--dz-alert-red)" : "var(--dz-ok)" }}
        >
          {isAlert ? t("guardian.badge.alert") : t("guardian.badge.safe")}
        </div>
        <h1 className="mt-4 text-[24px] font-extrabold leading-tight" style={{ color: "var(--dz-ink)" }}>
          {isAlert ? t("guardian.daily.alertTitle") : t("guardian.daily.wellTitle", { who })}
        </h1>
        <p className="mt-1.5 text-sm" style={{ color: isAlert ? "var(--dz-alert-red)" : "var(--dz-sub)" }}>
          {isAlert ? t("guardian.daily.alertSub") : t("guardian.daily.wellSub", { loc })}
        </p>
        <svg className="mx-auto mt-4 h-7 w-[130px]" viewBox="0 0 160 40" aria-hidden>
          <path
            d="M5 24 C25 24 25 12 42 12 S61 30 78 22 S100 8 115 18 S130 25 155 16"
            fill="none"
            stroke={isAlert ? "var(--dz-alert-red)" : "var(--dz-green)"}
            strokeWidth="4"
            strokeLinecap="round"
          />
        </svg>
      </article>

      {/* 奶奶状态卡 */}
      <section
        data-el="daily-elder-card"
        className="mt-4 flex items-center gap-3.5 rounded-[16px] p-4"
        style={{ background: "#fff", border: "1px solid var(--dz-line)" }}
      >
        <div className="grid h-[52px] w-[52px] place-items-center rounded-[14px]" style={{ background: "#f4f6f3", color: "var(--dz-sub)" }}>
          <UserRound size={26} strokeWidth={1.8} />
        </div>
        <div className="flex-1">
          <h2 className="m-0 text-[17px] font-extrabold leading-tight" style={{ color: "var(--dz-ink)" }}>
            {profile.name} · {t("guardian.unit.age", { age: profile.age })}
          </h2>
          <p className="mt-1 text-[13px]" style={{ color: "var(--dz-sub)" }}>
            {loc} · {isAlert ? t("guardian.breath.weak") : t("guardian.breath.steady")}
          </p>
        </div>
        <div className="text-right">
          <div className="text-2xl font-extrabold leading-none" style={{ color: isAlert ? "var(--dz-alert-red)" : "var(--dz-orange)" }}>
            {play.breathingRate}
          </div>
          <div className="text-xs" style={{ color: "var(--dz-sub)" }}>{t("guardian.unit.bpm")}</div>
        </div>
      </section>

      {/* 守护时间线 */}
      <section data-el="daily-timeline" className="mt-5 grid gap-2" aria-label={t("guardian.daily.timeline")}>
        <h3 className="mb-1 text-sm font-bold" style={{ color: "var(--dz-ink)" }}>{t("guardian.daily.timeline")}</h3>
        {TIMELINE.map((ev) => {
          const open = openRow === ev.id;
          const TIcon = TIMELINE_ICON[ev.id] ?? Sunrise;
          return (
            <button
              key={ev.id}
              data-el="timeline-row"
              onClick={() => setOpenRow(open ? null : ev.id)}
              className="grid w-full grid-cols-[40px_1fr_auto] items-center gap-3 rounded-[14px] p-3.5 text-left transition-colors"
              style={{ background: "#fff", border: "1px solid var(--dz-line)" }}
            >
              <span className="grid h-10 w-10 place-items-center rounded-[12px]" style={{ background: "#f4f6f3", color: "var(--dz-orange)" }}>
                <TIcon size={19} strokeWidth={1.9} />
              </span>
              <span className="min-w-0">
                <span className="block font-bold" style={{ color: "var(--dz-ink)" }}>{ev.time} {t(ev.titleKey)}</span>
                <span className="mt-0.5 block text-xs" style={{ color: "var(--dz-sub)" }}>{t(ev.descKey)}</span>
                {open && <span className="mt-2 block text-xs leading-relaxed" style={{ color: "var(--dz-ink)" }}>{t(ev.detailKey)}</span>}
              </span>
              <span className="text-xs font-semibold" style={{ color: "var(--dz-orange)" }}>{t(ev.tagKey)}</span>
            </button>
          );
        })}
      </section>
    </AppShell>
  );
}
