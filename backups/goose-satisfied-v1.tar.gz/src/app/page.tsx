"use client";

// 开头主视觉 · 家的光：护家鹅暖光开屏，插画为全屏英雄，点击进入平安日常
import Link from "next/link";
import Image from "next/image";
import { useTranslation } from "react-i18next";
import { ArrowRight } from "lucide-react";
import { GooseMark } from "@/components/guardian/brand-mark";

export default function SplashPage() {
  const { t } = useTranslation();
  return (
    <main
      data-el="splash-screen"
      className="relative flex min-h-[100svh] flex-col overflow-hidden"
      style={{ background: "#faf3e3" }}
    >
      {/* 全屏护家鹅主视觉插画 */}
      <div className="pointer-events-none absolute inset-0 z-0" aria-hidden>
        <Image
          src="/splash-goose.png"
          alt=""
          fill
          priority
          sizes="100vw"
          className="object-cover"
          style={{ objectPosition: "center 32%" }}
        />
        {/* 顶部轻遮罩：让品牌条可读；底部较强遮罩：让文案与按钮可读 */}
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(to bottom, rgba(250,243,227,.34) 0%, rgba(250,243,227,0) 26%, rgba(250,243,227,0) 52%, rgba(250,243,227,.72) 78%, rgba(250,243,227,.96) 100%)",
          }}
        />
      </div>

      <section
        className="relative z-10 mx-auto flex w-full max-w-[460px] flex-1 flex-col px-6"
        style={{
          paddingTop: "max(56px, env(safe-area-inset-top,0px))",
          paddingBottom: "max(40px, env(safe-area-inset-bottom,0px))",
        }}
      >
        {/* 品牌条 */}
        <div
          className="flex w-fit items-center gap-2.5 rounded-full px-3 py-2"
          style={{ background: "rgba(250,243,227,.62)", backdropFilter: "blur(14px)", boxShadow: "0 10px 30px rgba(52,65,60,.1)" }}
        >
          <span
            className="grid h-7 w-7 place-items-center rounded-full"
            style={{ background: "#fff", color: "var(--dz-orange)", boxShadow: "inset 0 -4px 8px rgba(233,130,67,.14)" }}
          >
            <GooseMark size={17} />
          </span>
          <span className="font-heading text-[15px] font-extrabold tracking-wide">
            鹅在
          </span>
        </div>

        <div className="flex-1" />

        {/* 文案 + 进入按钮 */}
        <div className="text-center" style={{ textShadow: "0 2px 18px rgba(250,243,227,.9)" }}>
          <h1
            className="font-heading font-extrabold leading-[1.05]"
            style={{ fontSize: "clamp(44px,13vw,72px)", letterSpacing: "-0.015em", color: "#34413c" }}
          >
            {t("guardian.splash.title")}
          </h1>
          <p
            className="mx-auto mt-3 max-w-[14em] text-[17px] font-medium leading-relaxed"
            style={{ color: "rgba(52,65,60,.9)" }}
          >
            {t("guardian.splash.line")}
          </p>
        </div>

        <Link
          href="/daily"
          data-el="splash-enter"
          className="mt-7 grid min-h-[58px] w-full max-w-[340px] grid-cols-[1fr_auto] items-center gap-3 justify-self-center self-center rounded-full px-6 font-bold text-[#fffaf1] transition-transform active:translate-y-0.5 active:scale-[.985]"
          style={{
            background: "linear-gradient(135deg,#E98243,#D96B2E)",
            boxShadow: "0 18px 42px rgba(233,130,67,.34), inset 0 1px 0 rgba(255,255,255,.45)",
          }}
        >
          <span>{t("guardian.splash.enter")}</span>
          <span className="grid h-[34px] w-[34px] place-items-center rounded-full" style={{ background: "rgba(255,255,255,.24)" }}>
            <ArrowRight size={20} />
          </span>
        </Link>
      </section>
    </main>
  );
}
