"use client";

// 数据页：实时活动曲线 + 呼吸波形（对齐真实剧本段落）+ 场景切换；告警仅在页内以警示态展示，不自动跳转
import { useEffect, type ReactNode } from "react";
import { useTranslation } from "react-i18next";
import { AppShell } from "@/components/guardian/app-shell";
import { BreathWaveform } from "@/components/guardian/breath-waveform";
import { ActivityCurve } from "@/components/guardian/activity-curve";
import { useGuardian } from "@/stores/guardian-store";
import { SCENARIOS } from "@/lib/guardian/data";
import { useScenarioPlayback } from "@/lib/guardian/use-scenario-playback";
import type { Scenario } from "@/lib/guardian/types";
import { CheckCircle2, Sofa, Footprints, AlertTriangle, type LucideIcon } from "lucide-react";

const SCENARIO_ICON: Record<string, LucideIcon> = {
  demo_rest: Sofa,
  demo_active: Footprints,
  demo_fall_still: AlertTriangle,
  demo_fall_moving: AlertTriangle,
  demo_fall_noresponse: AlertTriangle,
};

// 数据页顶部芯片：只展示「日常两个 + 合并的跌倒告警」，不再细分静止/运动/无响应。
// 合并告警统一映射到 demo_fall_still 剧本。
const DATA_CHIPS: { key: Scenario; labelKey: string; danger: boolean }[] = [
  { key: "demo_rest", labelKey: "guardian.scenario.demo_rest", danger: false },
  { key: "demo_active", labelKey: "guardian.scenario.demo_active", danger: false },
  { key: "demo_fall_still", labelKey: "guardian.scenario.fall_merged", danger: true },
];

const BREATH_LABEL: Record<string, string> = {
  normal: "guardian.breath.normal",
  elevated: "guardian.breath.elevated",
  irregular: "guardian.breath.irregular",
  shallow: "guardian.breath.shallow",
  lost: "guardian.breath.lost",
};

export default function DataPage() {
  const { scenario, setScenario } = useGuardian();
  const { t } = useTranslation();
  const meta = SCENARIOS[scenario];
  const play = useScenarioPlayback(meta);
  const seg = play.segment;
  const isAlertSeg = seg.zone === "alert";

  // 数据页每次进入时，若残留的是告警场景则重置为正常态，保证进入即为正常数据展示。
  useEffect(() => {
    if (SCENARIOS[scenario]?.zone === "alert") {
      setScenario("demo_rest");
    }
    // 仅在挂载时执行一次
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function onPick(s: Scenario) {
    setScenario(s);
  }

  return (
    <AppShell gradient>
      <header className="mb-4 mt-1">
        <h1 className="text-[26px] font-extrabold leading-tight" style={{ color: "var(--dz-ink)" }}>{t("guardian.data.title")}</h1>
      </header>

      {/* 场景切换芯片：日常两个 + 合并的跌倒告警 */}
      <div
        data-el="data-scenario-chips"
        className="-mx-4 mb-4 flex gap-2 overflow-x-auto px-4 pb-1"
        style={{ scrollbarWidth: "none" }}
      >
        {DATA_CHIPS.map((c) => {
          // 任一告警剧本都让「跌倒告警」芯片处于激活态
          const active = c.danger
            ? SCENARIOS[scenario]?.zone === "alert"
            : c.key === scenario;
          const SIcon = SCENARIO_ICON[c.key] ?? Sofa;
          return (
            <button
              key={c.key}
              data-el={`scenario-${c.key}`}
              onClick={() => onPick(c.key)}
              className="flex shrink-0 items-center gap-1.5 rounded-full px-4 py-2 text-sm font-semibold whitespace-nowrap transition-transform active:scale-95"
              style={
                active
                  ? { background: c.danger ? "#e0452a" : "var(--dz-orange)", color: "#fff" }
                  : { background: "#fff", color: c.danger ? "#e0452a" : "var(--dz-sub)", border: "1px solid var(--dz-line)" }
              }
            >
              <SIcon size={15} strokeWidth={2} />
              {t(c.labelKey)}
            </button>
          );
        })}
      </div>

      <div className="space-y-4">
        {/* KPI 卡：呼吸大数字 + 当前段落 */}
        <DataCard el="data-kpi-card">
          <div className="flex items-end justify-between">
            <div>
              <div className="text-sm font-bold" style={{ color: "var(--dz-sub)" }}>{t("guardian.data.breathTitle")}</div>
              <div className="mt-1 flex items-baseline gap-2">
                <span className="text-[44px] font-extrabold leading-none" style={{ color: isAlertSeg ? "#e0452a" : "var(--dz-ink)" }}>{play.breathingRate}</span>
                <span className="text-sm" style={{ color: "var(--dz-sub)" }}>{t("guardian.unit.bpm")}</span>
              </div>
            </div>
            <span
              className="rounded-full px-3 py-1 text-xs font-bold"
              style={{
                background: isAlertSeg ? "rgba(224,69,42,.1)" : "#f2f8f1",
                color: isAlertSeg ? "#e0452a" : "var(--dz-ok)",
              }}
            >
              {t(BREATH_LABEL[play.breathingState] ?? "guardian.breath.normal")}
            </span>
          </div>
          <div
            className="mt-3 border-t pt-2.5 text-xs font-medium leading-relaxed"
            style={{ borderColor: "var(--dz-line)", color: isAlertSeg ? "#e0452a" : "var(--dz-sub)" }}
          >
            <span className="opacity-70">{play.segIndex + 1}/{meta.segments.length} · </span>
            {t(seg.labelKey)}
          </div>
        </DataCard>

        {/* 活动趋势卡 */}
        <DataCard el="data-activity-card">
          <div className="mb-2 flex items-center justify-between">
            <div className="text-sm font-bold" style={{ color: "var(--dz-ink)" }}>{t("guardian.data.activity")}</div>
            <div className="text-xs font-bold" style={{ color: isAlertSeg ? "#e0452a" : "var(--dz-orange)" }}>
              {seg.pattern === "spike" ? t("guardian.data.spike", { x: "4.2" }) : `${play.activity}%`}
            </div>
          </div>
          <div className="flex gap-2">
            <div className="min-w-0 flex-1 overflow-hidden rounded-[8px]">
              <ActivityCurve segment={seg} />
            </div>
            <ScaleLabels />
          </div>
          <TimeAxis />
        </DataCard>

        {/* 呼吸趋势卡 */}
        <DataCard el="data-breath-card">
          <div className="mb-2 flex items-center justify-between">
            <div className="text-sm font-bold" style={{ color: "var(--dz-ink)" }}>{t("guardian.data.breathTitle")}</div>
            <span className="text-xs font-bold" style={{ color: isAlertSeg ? "#e0452a" : "var(--dz-green)" }}>
              {t(BREATH_LABEL[play.breathingState] ?? "guardian.breath.normal")}
            </span>
          </div>
          <div className="flex gap-2">
            <div className="min-w-0 flex-1 overflow-hidden rounded-[8px]">
              <BreathWaveform segment={seg} height={110} />
            </div>
            <ScaleLabels />
          </div>
          <TimeAxis />
        </DataCard>

        {/* 结论条：绿对勾 */}
        <div
          data-el="data-evidence"
          className="flex items-center gap-2.5 rounded-[16px] px-4 py-3.5"
          style={{ background: "#f2f8f1", border: "1px solid #e4efe2" }}
        >
          <CheckCircle2 size={20} style={{ color: "var(--dz-ok)" }} className="shrink-0" />
          <p className="m-0 text-sm font-medium" style={{ color: "var(--dz-ink)" }}>
            {t("guardian.data.evidence")}
          </p>
        </div>
      </div>
    </AppShell>
  );
}

/** 统一白卡模块（对齐 2/4/5 页的卡片规格） */
function DataCard({ children, el }: { children: ReactNode; el: string }) {
  return (
    <section
      data-el={el}
      className="rounded-[16px] p-4"
      style={{ background: "#fff", border: "1px solid var(--dz-line)" }}
    >
      {children}
    </section>
  );
}

/** 右侧 高/中/低 刻度 */
function ScaleLabels() {
  const { t } = useTranslation();
  return (
    <div className="flex w-7 shrink-0 flex-col justify-between py-1 text-[10px]" style={{ color: "var(--dz-sub)" }}>
      <span>{t("guardian.data.high")}</span>
      <span>{t("guardian.data.mid")}</span>
      <span>{t("guardian.data.low")}</span>
    </div>
  );
}

/** 底部时间轴 00:00 ~ 24:00 */
function TimeAxis() {
  return (
    <div className="mt-1 flex justify-between pr-9 text-[10px]" style={{ color: "var(--dz-sub)" }}>
      {["00:00", "06:00", "12:00", "18:00", "24:00"].map((tm) => (
        <span key={tm}>{tm}</span>
      ))}
    </div>
  );
}
