"use client";

// 紧急告警异常页：全屏珊瑚红接管 + 持续震动 + 双证据线 + 逐级一键拨号
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useTranslation } from "react-i18next";
import { useGuardian, vibrate } from "@/stores/guardian-store";
import { Phone, RotateCw, Wifi, HeartPulse, ChevronRight } from "lucide-react";

export default function AlertPage() {
  const { profile, scenario, acknowledgeAlert } = useGuardian();
  const router = useRouter();
  const { t, i18n } = useTranslation();
  const [acked, setAcked] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const buzzTimer = useRef<ReturnType<typeof setInterval> | null>(null);

  // 告警文案随触发场景动态：优先 alert.scenario.<场景>.<字段>，否则回落通用文案。
  const ta = (field: string, opts?: Record<string, unknown>) => {
    const scoped = `guardian.alert.scenario.${scenario}.${field}`;
    return i18n.exists(scoped) ? t(scoped, opts) : t(`guardian.alert.${field}`, opts);
  };

  // 进入即持续震动（每 3s 一轮）直到确认
  useEffect(() => {
    vibrate([200, 100, 200, 100, 320]);
    buzzTimer.current = setInterval(() => {
      if (!acked) vibrate([200, 100, 200, 100, 320]);
    }, 3000);
    const t = setInterval(() => setElapsed((e) => e + 1), 1000);
    return () => {
      if (buzzTimer.current) clearInterval(buzzTimer.current);
      clearInterval(t);
    };
  }, [acked]);

  function onAck() {
    setAcked(true);
    if (buzzTimer.current) clearInterval(buzzTimer.current);
    vibrate(60);
    acknowledgeAlert();
    setTimeout(() => router.push("/daily"), 900);
  }

  const mm = String(Math.floor(elapsed / 60)).padStart(2, "0");
  const ss = String(elapsed % 60).padStart(2, "0");
  const who = t(`guardian.relationship.${profile.relationshipKey}`);
  const loc = t(`guardian.location.${profile.locationKey}`);

  return (
    <main
      data-el="alert-screen"
      className="relative min-h-[100svh] overflow-hidden"
      style={{
        background: "var(--dz-alert)",
        paddingTop: "max(52px, env(safe-area-inset-top,0px))",
        paddingBottom: "max(30px, env(safe-area-inset-bottom,0px))",
        color: "#fff",
      }}
    >
      <section className="relative z-10 mx-auto flex min-h-full w-full max-w-[460px] flex-col px-6">
        {/* 顶栏计时 */}
        <div className="flex items-center justify-center">
          <span className="flex items-center gap-1.5 text-xs font-semibold" style={{ color: "rgba(255,255,255,.9)" }}>
            <span className="h-1.5 w-1.5 rounded-full bg-white" />
            {t("guardian.alert.alarming", { time: `${mm}:${ss}` })}
          </span>
        </div>

        {/* 大标题区 */}
        <div className="mt-8 text-center" data-el="alert-heading">
          <span className="inline-block rounded-full bg-white/90 px-3 py-1 text-xs font-bold" style={{ color: "var(--dz-alert-red)" }}>
            {ta("tag")}
          </span>
          <h1 className="mt-4 text-[30px] font-extrabold leading-tight" style={{ textShadow: "0 2px 12px rgba(160,40,20,.28)" }}>
            {ta("title", { who })}
          </h1>
          <p className="mt-2 text-sm font-medium" style={{ color: "rgba(255,255,255,.9)" }}>
            {ta("meta", { loc, time: `${mm}:${ss}` })}
          </p>
        </div>

        {/* 白色证据卡：呼吸 + 设备在线 */}
        <div className="mt-7 overflow-hidden rounded-[22px] bg-white" data-el="alert-evidence" style={{ boxShadow: "0 18px 40px rgba(150,40,20,.22)" }}>
          <div className="flex items-center gap-3 px-4 py-3.5">
            <HeartPulse size={20} style={{ color: "var(--dz-alert-red)" }} className="shrink-0" />
            <div className="min-w-0 flex-1">
              <div className="text-sm font-bold" style={{ color: "var(--dz-ink)" }}>{ta("breathEvi")} · {ta("breathVal")}</div>
            </div>
          </div>
          <div className="h-px" style={{ background: "var(--dz-line)" }} />
          <div className="flex items-center gap-3 px-4 py-3.5">
            <Wifi size={20} style={{ color: "var(--dz-ok)" }} className="shrink-0" />
            <div className="text-sm font-bold" style={{ color: "var(--dz-ink)" }}>{t("guardian.alert.deviceOnline")}</div>
          </div>
        </div>

        {/* 逐级拨号：保留联系人列表，采用白底椭圆红字样式 */}
        <section data-el="alert-call-board" className="mt-6 flex flex-1 flex-col gap-2.5">
          <h2 className="text-center text-xs font-semibold" style={{ color: "rgba(255,255,255,.85)" }}>{t("guardian.alert.callTitle")}</h2>
          {profile.contacts.map((c) => (
            <a
              key={c.id}
              href={`tel:${c.phone}`}
              data-el="alert-call-btn"
              onPointerDown={() => vibrate(40)}
              className="flex items-center gap-3 rounded-full bg-white px-5 py-3.5 transition-transform active:scale-[.98]"
              style={{ boxShadow: "0 10px 24px rgba(150,40,20,.16)" }}
            >
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full text-sm font-extrabold" style={{ background: "rgba(224,69,42,.12)", color: "var(--dz-alert-red)" }}>
                {c.rank}
              </span>
              <span className="min-w-0 flex-1 text-left">
                <span className="block truncate font-extrabold" style={{ color: "var(--dz-ink)" }}>{c.name}</span>
                <span className="text-xs" style={{ color: "var(--dz-sub)" }}>{c.phone} · {t(c.relationshipKey)}</span>
              </span>
              <Phone size={18} style={{ color: "var(--dz-alert-red)" }} />
            </a>
          ))}
        </section>

        {/* 底部操作 */}
        <div className="mt-5 flex gap-3">
          <button
            data-el="alert-ack"
            onClick={onAck}
            className="flex-1 rounded-full bg-white py-3.5 text-base font-extrabold transition-transform active:scale-[.98]"
            style={{ color: "var(--dz-alert-red)", boxShadow: "0 14px 28px rgba(150,40,20,.2)" }}
          >
            {acked ? t("guardian.alert.acking") : t("guardian.alert.ack")}
          </button>
          <button
            data-el="alert-rebuzz"
            onClick={() => vibrate([200, 100, 200, 100, 320])}
            aria-label={t("guardian.alert.rebuzz")}
            className="grid w-14 place-items-center rounded-full transition-transform active:scale-95"
            style={{ background: "rgba(255,255,255,.2)", border: "1px solid rgba(255,255,255,.4)" }}
          >
            <RotateCw size={22} />
          </button>
        </div>
        <p className="mt-4 flex items-center justify-center gap-1 text-xs" style={{ color: "rgba(255,255,255,.85)" }}>
          {t("guardian.alert.evidenceLink")} <ChevronRight size={13} />
        </p>
      </section>
    </main>
  );
}
