"use client";

// 实时呼吸波形（canvas 滚动绘制），依据当前剧本段落的呼吸带/态调整振幅、频率、颜色
import { useEffect, useRef } from "react";
import type { ScenarioSegment } from "@/lib/guardian/types";

export function BreathWaveform({
  segment,
  height = 120,
}: {
  segment: ScenarioSegment;
  height?: number;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const segRef = useRef(segment);

  useEffect(() => {
    segRef.current = segment;
  }, [segment]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduced =
      typeof window !== "undefined" &&
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

    let raf = 0;
    let t = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    function resize() {
      const w = canvas!.clientWidth;
      canvas!.width = w * dpr;
      canvas!.height = height * dpr;
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    function draw() {
      const w = canvas!.clientWidth;
      const seg = segRef.current;
      const isAlert = seg.zone === "alert";
      const isWatch = seg.zone === "watch";
      // 设计同学风格：呼吸线常态墨绿，告警红、观察橙
      const strokeColor = isAlert ? "#e0452a" : isWatch ? "#c98a3c" : "#6f9b6e";
      const fillTop = isAlert ? "rgba(224,69,42,0.16)" : isWatch ? "rgba(201,138,60,0.16)" : "rgba(111,155,110,0.20)";
      ctx!.clearRect(0, 0, w, height);

      const rate = (seg.brLow + seg.brHigh) / 2;
      const st = seg.brState ?? "normal";
      const shallow = st === "shallow" || st === "lost";
      const irregular = st === "irregular";
      const amp = (height / 2.6) * (shallow ? 0.4 : irregular ? 0.75 : 1);
      const jitter = irregular ? 0.5 : shallow ? 0.25 : 0.08;
      const cycle = 0.03 + (rate / 20) * 0.05;

      let seed = 1;
      const rand = () => {
        seed = (seed * 9301 + 49297) % 233280;
        return seed / 233280;
      };

      // 先描线路径的点，用于面积填充与描边
      const mid = height / 2;
      const pts: [number, number][] = [];
      for (let x = 0; x <= w; x += 2) {
        const phase = (x + t) * cycle;
        const j = (rand() - 0.5) * amp * jitter;
        const y = mid - Math.sin(phase) * amp + j;
        pts.push([x, y]);
      }

      // 面积渐变填充（线下方到底部）
      const grad = ctx!.createLinearGradient(0, 0, 0, height);
      grad.addColorStop(0, fillTop);
      grad.addColorStop(1, "rgba(255,255,255,0)");
      ctx!.beginPath();
      ctx!.moveTo(pts[0][0], pts[0][1]);
      for (const [x, y] of pts) ctx!.lineTo(x, y);
      ctx!.lineTo(w, height);
      ctx!.lineTo(0, height);
      ctx!.closePath();
      ctx!.fillStyle = grad;
      ctx!.fill();

      // 描边
      ctx!.beginPath();
      ctx!.moveTo(pts[0][0], pts[0][1]);
      for (const [x, y] of pts) ctx!.lineTo(x, y);
      ctx!.strokeStyle = strokeColor;
      ctx!.lineWidth = 2.5;
      ctx!.lineJoin = "round";
      ctx!.lineCap = "round";
      ctx!.stroke();

      t += rate > 20 ? 2.6 : 1.6;
      raf = requestAnimationFrame(draw);
    }

    if (reduced) draw();
    else raf = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, [height]);

  return <canvas ref={canvasRef} className="block w-full" style={{ height }} />;
}
