"use client";

// 极简白底页面外壳（设计同学视觉）：白背景 + 底部线性导航
import type { ReactNode } from "react";
import { BottomNav } from "./bottom-nav";
import { SettingsSheet } from "./settings-sheet";
import { SimAlertTrigger } from "./sim-alert-trigger";

export function AppShell({
  children,
  showNav = true,
  gradient = false,
}: {
  children: ReactNode;
  showNav?: boolean;
  gradient?: boolean;
}) {
  return (
    <div
      className="relative flex min-h-full flex-col"
      style={{ background: gradient ? "var(--dz-grad)" : "var(--dz-bg)" }}
    >
      <div
        className="relative z-10 mx-auto w-full max-w-[460px] flex-1 px-4"
        style={{
          paddingTop: "max(20px, env(safe-area-inset-top, 0px))",
          paddingBottom: showNav ? 108 : 24,
        }}
      >
        <div className="mb-1 flex items-center justify-between" data-el="settings-entry">
          <SimAlertTrigger />
          <SettingsSheet />
        </div>
        {children}
      </div>
      {showNav && <BottomNav />}
    </div>
  );
}
