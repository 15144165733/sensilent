"use client";

// 软糖风设置面板：语言切换（中文/English/跟随系统），品牌化样式
import { useCallback, useState, useSyncExternalStore } from "react";
import { Settings, X, Check, Globe, RotateCcw } from "lucide-react";
import { useTranslation } from "react-i18next";
import { useGuardian } from "@/stores/guardian-store";
import {
  changeLocale,
  getLocalePreference,
  normalizeLocale,
  type LocaleCode,
  type LocalePreference,
} from "@/i18n";

const OPTIONS: { value: string; labelKey: string }[] = [
  { value: "zh-CN", labelKey: "language.zhCN" },
  { value: "en-US", labelKey: "language.enUS" },
  { value: "system", labelKey: "language.followSystem" },
];

export function SettingsSheet() {
  const { t, i18n } = useTranslation();
  const [open, setOpen] = useState(false);
  const { resetDemo } = useGuardian();

  const subscribe = useCallback(
    (sync: () => void) => {
      i18n.on("languageChanged", sync);
      window.addEventListener("eazo-locale-preference-changed", sync);
      window.addEventListener("storage", sync);
      return () => {
        i18n.off("languageChanged", sync);
        window.removeEventListener("eazo-locale-preference-changed", sync);
        window.removeEventListener("storage", sync);
      };
    },
    [i18n],
  );
  const preference = useSyncExternalStore(
    subscribe,
    getLocalePreference,
    () => "system" as LocalePreference,
  );

  async function pick(value: string) {
    if (value === "system") await changeLocale("system");
    else {
      const locale = normalizeLocale(value);
      if (locale) await changeLocale(locale as LocaleCode);
    }
  }

  return (
    <>
      <button
        data-el="settings-open"
        aria-label={t("guardian.settings.open")}
        onClick={() => setOpen(true)}
        className="grid h-9 w-9 place-items-center rounded-full transition-transform active:scale-90"
        style={{ background: "rgba(255,250,240,.86)", color: "var(--wg-ink)", boxShadow: "var(--wg-inset)" }}
      >
        <Settings size={18} />
      </button>

      {open && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center"
          style={{ background: "rgba(52,65,60,.4)", backdropFilter: "blur(2px)" }}
          onClick={() => setOpen(false)}
          data-el="settings-overlay"
        >
          <div
            className="w-full max-w-[460px] rounded-t-[32px] p-6"
            style={{
              background: "linear-gradient(180deg,#fffbf2,#faf3e3)",
              boxShadow: "0 -18px 40px rgba(52,65,60,.2)",
              paddingBottom: "max(28px, env(safe-area-inset-bottom,0px))",
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-heading text-xl font-extrabold">{t("guardian.settings.title")}</h2>
              <button
                data-el="settings-close"
                aria-label={t("guardian.settings.close")}
                onClick={() => setOpen(false)}
                className="grid h-8 w-8 place-items-center rounded-full"
                style={{ background: "rgba(191,217,205,.4)", color: "var(--wg-ink)" }}
              >
                <X size={16} />
              </button>
            </div>

            <div className="mb-2 flex items-center gap-2 text-[13px] font-bold" style={{ color: "rgba(52,65,60,.6)" }}>
              <Globe size={15} /> {t("guardian.settings.language")}
            </div>
            <div className="grid gap-2.5">
              {OPTIONS.map((o) => {
                const active = preference === o.value;
                return (
                  <button
                    key={o.value}
                    data-el={`settings-lang-${o.value}`}
                    onClick={() => void pick(o.value)}
                    className="flex items-center justify-between rounded-[20px] px-4 py-3.5 text-left font-bold transition-transform active:scale-[.98]"
                    style={
                      active
                        ? { background: "var(--wg-orange)", color: "#fff", boxShadow: "0 10px 22px rgba(233,130,67,.3)" }
                        : { background: "rgba(255,250,240,.9)", color: "var(--wg-ink)", boxShadow: "var(--wg-inset)" }
                    }
                  >
                    {t(o.labelKey)}
                    {active && <Check size={18} />}
                  </button>
                );
              })}
            </div>

            <button
              data-el="settings-reset"
              onClick={() => { resetDemo(); setOpen(false); }}
              className="mt-5 flex w-full items-center justify-center gap-2 rounded-[20px] px-4 py-3.5 font-bold transition-transform active:scale-[.98]"
              style={{ background: "rgba(191,217,205,.4)", color: "var(--wg-ink)", boxShadow: "var(--wg-inset)" }}
            >
              <RotateCcw size={16} /> {t("guardian.settings.reset")}
            </button>
          </div>
        </div>
      )}
    </>
  );
}
