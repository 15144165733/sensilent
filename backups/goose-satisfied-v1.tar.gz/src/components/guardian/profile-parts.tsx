"use client";

// 档案页复用小部件：卡片容器 / 卡头(微调) / 字段 / 计数器
import type { ReactNode } from "react";
import { Pencil, Check } from "lucide-react";
import { useTranslation } from "react-i18next";

export function Card({ el, children }: { el: string; children: ReactNode }) {
  return (
    <section data-el={el} className="mt-4 rounded-[16px] p-5"
      style={{ background: "#fff", border: "1px solid var(--dz-line)" }}>
      {children}
    </section>
  );
}

export function CardHead({ title, editing, onToggle, el }: { title: string; editing: boolean; onToggle: () => void; el: string }) {
  const { t } = useTranslation();
  return (
    <div className="flex items-center justify-between">
      <div className="text-sm font-bold" style={{ color: "var(--dz-ink)" }}>{title}</div>
      <button data-el={el} onClick={onToggle}
        className="flex items-center gap-1 rounded-full px-3 py-1.5 text-xs font-semibold transition-transform active:scale-95"
        style={{ background: editing ? "var(--dz-orange)" : "#f4f6f3", color: editing ? "#fff" : "var(--dz-sub)", border: editing ? "none" : "1px solid var(--dz-line)" }}>
        {editing ? <Check size={14} /> : <Pencil size={14} />}
        {editing ? t("guardian.profile.done") : t("guardian.profile.tune")}
      </button>
    </div>
  );
}

export function Field({ label, value, editing, onChange, type = "text" }: { label: string; value: string; editing: boolean; onChange: (v: string) => void; type?: string }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="shrink-0 text-sm" style={{ color: "var(--dz-sub)" }}>{label}</span>
      {editing ? (
        <input data-el="profile-field-input" type={type} defaultValue={value} onBlur={(e) => onChange(e.target.value)}
          className="w-[58%] rounded-[10px] bg-white px-2.5 py-1.5 text-right text-sm outline-none" style={{ border: "1px solid var(--dz-line)" }} />
      ) : (
        <span className="truncate text-right text-sm font-bold" style={{ color: "var(--dz-ink)" }}>{value}</span>
      )}
    </div>
  );
}

export function Stepper({ label, value, onChange, el }: { label: string; value: number; onChange: (v: number) => void; el: string }) {
  return (
    <div data-el={`profile-stepper-${el}`} className="rounded-[12px] px-3 py-2.5" style={{ background: "#f4f6f3", border: "1px solid var(--dz-line)" }}>
      <div className="text-xs" style={{ color: "var(--dz-sub)" }}>{label}</div>
      <div className="mt-1.5 flex items-center justify-between">
        <button aria-label="minus" onClick={() => onChange(Math.max(0, value - 1))}
          className="grid h-7 w-7 place-items-center rounded-full font-bold" style={{ background: "#fff", color: "var(--dz-ink)", border: "1px solid var(--dz-line)" }}>−</button>
        <span className="text-lg font-extrabold" style={{ color: "var(--dz-ink)" }}>{value}</span>
        <button aria-label="plus" onClick={() => onChange(value + 1)}
          className="grid h-7 w-7 place-items-center rounded-full font-bold text-white" style={{ background: "var(--dz-orange)" }}>+</button>
      </div>
    </div>
  );
}
