"use client";

// 临时演示入口：一键模拟硬件上报「跌倒」事件 → 主动全屏弹出告警。
// 现场无法操作真实毫米波硬件，用此按钮模拟硬件主动触发；真实场景由设备事件驱动。
import { useRouter } from "next/navigation";
import { useTranslation } from "react-i18next";
import { Siren } from "lucide-react";
import { useGuardian, vibrate } from "@/stores/guardian-store";

export function SimAlertTrigger() {
  const { t } = useTranslation();
  const router = useRouter();
  const { setScenario } = useGuardian();

  function fire() {
    setScenario("demo_fall_still"); // 标记为告警场景，重置确认态
    vibrate([200, 100, 200, 100, 320]);
    router.push("/alert"); // 主动全屏接管
  }

  return (
    <button
      data-el="sim-alert-open"
      aria-label={t("guardian.sim.open")}
      onClick={fire}
      className="flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-extrabold transition-transform active:scale-90"
      style={{ background: "rgba(216,88,77,.14)", color: "#c0392e", border: "1px solid rgba(216,88,77,.3)" }}
    >
      <Siren size={14} /> {t("guardian.sim.label")}
    </button>
  );
}
