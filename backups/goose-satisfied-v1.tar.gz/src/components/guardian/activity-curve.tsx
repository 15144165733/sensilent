"use client";

// 实时活动强度曲线（canvas 滚动折线），依据当前剧本段落运动带 [low,high] 与 pattern 推进
import { useEffect, useRef } from "react";
import type { ScenarioSegment } from "@/lib/guardian/types";

export function ActivityCurve({
  segment,
  height = 96,
}: {
  segment: ScenarioSegment;
  height?: number;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const segRef = useRef(segment);
  const bufRef = useRef<number[]>([]);

  useEffect(() => {
    segRef.current = segment;
  }, [segment]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduced =
      typeof window !== "undefined" &&
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const POINTS = 60;
    if (bufRef.current.length === 0)
      bufRef.current = Array.from({ length: POINTS }, () => 8);

    function resize() {
      const w = canvas!.clientWidth;
      canvas!.width = w * dpr;
      canvas!.height = height * dpr;
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    let raf = 0;
    let tick = 0;

    function nextValue(): number {
      const seg = segRef.current;
      // 运动带 low/high 为 0-1，映射到 0-100
      const lo = seg.low * 100;
      const hi = seg.high * 100;
      if (seg.pattern === "spike") {
        // 剧烈形变：贴近峰值并强抖动
        return Math.max(2, Math.min(100, hi - Math.random() * 12));
      }
      if (seg.pattern === "still") {
        // 静止：低幅微动
        return Math.max(1, lo + Math.random() * Math.max(2, hi - lo));
      }
      // active：在带内起伏
      return Math.max(2, Math.min(100, lo + Math.random() * (hi - lo) + (Math.random() - 0.5) * 10));
    }

    function step() {
      const seg = segRef.current;
      const buf = bufRef.current;
      if (tick % 5 === 0) {
        buf.push(nextValue());
        if (buf.length > POINTS) buf.shift();
      }
      tick++;

      const w = canvas!.clientWidth;
      ctx!.clearRect(0, 0, w, height);
      const isAlert = seg.zone === "alert";
      const isWatch = seg.zone === "watch" || seg.pattern === "spike";
      const stroke = isAlert ? "#e0452a" : isWatch ? "#e8823f" : "#e8823f";
      const gap = w / (POINTS - 1);

      ctx!.beginPath();
      buf.forEach((v, i) => {
        const x = i * gap;
        const y = height - (v / 100) * (height - 10) - 4;
        if (i === 0) ctx!.moveTo(x, y);
        else ctx!.lineTo(x, y);
      });
      const lastX = (buf.length - 1) * gap;
      ctx!.lineTo(lastX, height);
      ctx!.lineTo(0, height);
      ctx!.closePath();
      const grad = ctx!.createLinearGradient(0, 0, 0, height);
      grad.addColorStop(0, isAlert ? "rgba(216,88,77,0.28)" : "rgba(233,130,67,0.24)");
      grad.addColorStop(1, "rgba(233,130,67,0)");
      ctx!.fillStyle = grad;
      ctx!.fill();

      ctx!.beginPath();
      buf.forEach((v, i) => {
        const x = i * gap;
        const y = height - (v / 100) * (height - 10) - 4;
        if (i === 0) ctx!.moveTo(x, y);
        else ctx!.lineTo(x, y);
      });
      ctx!.strokeStyle = stroke;
      ctx!.lineWidth = 2.6;
      ctx!.lineJoin = "round";
      ctx!.stroke();

      raf = requestAnimationFrame(step);
    }

    if (reduced) step();
    else raf = requestAnimationFrame(step);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
    };
  }, [height]);

  return <canvas ref={canvasRef} className="block w-full" style={{ height }} />;
}
