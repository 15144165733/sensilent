"use client";

// 档案完整界面（供 /profile 路由渲染）：基本信息 / 健康与风险 / 紧急联系人
import { useState } from "react";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";
import { AppShell } from "@/components/guardian/app-shell";
import { useGuardian } from "@/stores/guardian-store";
import { HEALTH_STATUS_KEYS, DISEASE_KEYS } from "@/lib/guardian/data";
import {
  HealthPickerSheet,
  DiseasePickerSheet,
  ContactInlineEditor,
} from "@/components/guardian/profile-sheets";
import { Card, CardHead, Field, Stepper } from "@/components/guardian/profile-parts";
import { Pencil, Phone, ChevronRight, ArrowUp, UserRound } from "lucide-react";

export function ProfileScreen() {
  const { profile, updateProfile } = useGuardian();
  const { t } = useTranslation();
  const [editBasic, setEditBasic] = useState(false);
  const [editContacts, setEditContacts] = useState(false);
  const [healthOpen, setHealthOpen] = useState(false);
  const [diseaseOpen, setDiseaseOpen] = useState(false);
  const [editing, setEditing] = useState<string | null>(null);

  const who = t(`guardian.relationship.${profile.relationshipKey}`);
  const loc = t(`guardian.location.${profile.locationKey}`);

  function toggleDisease(k: string) {
    const has = profile.diseaseKeys.includes(k);
    updateProfile({
      diseaseKeys: has ? profile.diseaseKeys.filter((x) => x !== k) : [...profile.diseaseKeys, k],
    });
  }

  return (
    <AppShell gradient>
      <header className="mb-4 mt-1">
        <h1 className="text-[26px] font-extrabold leading-tight" style={{ color: "var(--dz-ink)" }}>{t("guardian.profile.title")}</h1>
        <p className="mt-1 text-[13px]" style={{ color: "var(--dz-sub)" }}>{t("guardian.profile.subtitle")}</p>
      </header>

      <section data-el="profile-hero" className="flex items-center gap-4 rounded-[16px] p-5"
        style={{ background: "#f4f6f3", border: "1px solid var(--dz-line)" }}>
        <div className="grid h-[64px] w-[64px] place-items-center rounded-[16px]"
          style={{ background: "#fff", border: "1px solid var(--dz-line)", color: "var(--dz-sub)" }}><UserRound size={32} strokeWidth={1.8} /></div>
        <div className="min-w-0 flex-1">
          <div className="text-xl font-extrabold" style={{ color: "var(--dz-ink)" }}>{profile.name}</div>
          <div className="mt-0.5 text-sm" style={{ color: "var(--dz-sub)" }}>
            {who} · {t("guardian.unit.age", { age: profile.age })} · {loc}
          </div>
        </div>
      </section>

      {/* 基本信息 */}
      <Card el="profile-basic">
        <CardHead title={t("guardian.profile.basic")} editing={editBasic} onToggle={() => setEditBasic((v) => !v)} el="profile-basic-edit" />
        <div className="mt-3 grid gap-3">
          <Field label={t("guardian.profile.field.relationship")} value={who} editing={false} onChange={() => {}} />
          <Field label={t("guardian.profile.field.name")} value={profile.name} editing={editBasic} onChange={(v) => updateProfile({ name: v })} />
          <Field label={t("guardian.profile.field.age")} value={String(profile.age)} editing={editBasic} type="number" onChange={(v) => updateProfile({ age: Number(v) || profile.age })} />
          <Field label={t("guardian.profile.field.weight")} value={String(profile.weightKg)} editing={editBasic} type="number" onChange={(v) => updateProfile({ weightKg: Number(v) || profile.weightKg })} />
          <Field label={t("guardian.profile.field.wake")} value={profile.wakeTime} editing={editBasic} onChange={(v) => updateProfile({ wakeTime: v })} />
          <Field label={t("guardian.profile.field.sleep")} value={profile.sleepTime} editing={editBasic} onChange={(v) => updateProfile({ sleepTime: v })} />
          <Field label={t("guardian.profile.field.address")} value={profile.address} editing={editBasic} onChange={(v) => updateProfile({ address: v })} />
        </div>
      </Card>

      {/* 健康与风险 */}
      <Card el="profile-health">
        <div className="text-sm font-bold" style={{ color: "var(--dz-ink)" }}>{t("guardian.profile.risk")}</div>

        <button data-el="profile-health-pick" onClick={() => setHealthOpen(true)}
          className="mt-3 flex w-full items-center justify-between rounded-[12px] px-4 py-3 text-left transition-colors"
          style={{ background: "#f4f6f3", border: "1px solid var(--dz-line)" }}>
          <span>
            <span className="block text-xs" style={{ color: "var(--dz-sub)" }}>{t("guardian.profile.health")}</span>
            <span className="mt-0.5 block font-extrabold" style={{ color: "var(--dz-ink)" }}>{t(`guardian.health.${profile.healthStatusKey}`)}</span>
            <span className="text-xs" style={{ color: "var(--dz-sub)" }}>{t(`guardian.health.${profile.healthStatusKey}_desc`)}</span>
          </span>
          <ChevronRight size={20} style={{ color: "var(--dz-sub)" }} />
        </button>

        <button data-el="profile-disease-pick" onClick={() => setDiseaseOpen(true)}
          className="mt-2.5 w-full rounded-[12px] px-4 py-3 text-left transition-colors"
          style={{ background: "#f4f6f3", border: "1px solid var(--dz-line)" }}>
          <span className="flex items-center justify-between">
            <span className="text-xs" style={{ color: "var(--dz-sub)" }}>{t("guardian.profile.diseaseTitle")}</span>
            <span className="flex items-center gap-1 text-xs font-bold" style={{ color: "var(--dz-orange)" }}>
              {t("guardian.profile.diseaseCount", { n: profile.diseaseKeys.length })}<ChevronRight size={16} />
            </span>
          </span>
          <span className="mt-2 flex flex-wrap gap-2">
            {profile.diseaseKeys.length === 0 && (
              <span className="text-xs" style={{ color: "var(--dz-sub)" }}>{t("guardian.profile.none")}</span>
            )}
            {profile.diseaseKeys.map((d) => (
              <span key={d} className="rounded-full px-3 py-1 text-xs font-bold" style={{ background: "rgba(232,130,63,.12)", color: "var(--dz-orange)" }}>
                {t(`guardian.disease.${d}`)}
              </span>
            ))}
          </span>
        </button>

        <div className="mt-2.5 grid grid-cols-2 gap-2.5">
          <Stepper label={t("guardian.profile.field.fall")} value={profile.fallCount} onChange={(v) => updateProfile({ fallCount: v })} el="fall" />
          <Stepper label={t("guardian.profile.field.syncope")} value={profile.syncopeCount} onChange={(v) => updateProfile({ syncopeCount: v })} el="syncope" />
        </div>
        <button data-el="profile-scd-toggle" onClick={() => updateProfile({ familySuddenCardiacDeath: !profile.familySuddenCardiacDeath })}
          className="mt-2.5 flex w-full items-center justify-between rounded-[12px] px-4 py-3 text-left transition-colors"
          style={{ background: "#f4f6f3", border: "1px solid var(--dz-line)" }}>
          <span className="text-sm font-medium" style={{ color: "var(--dz-ink)" }}>{t("guardian.profile.field.family_scd")}</span>
          <span className="rounded-full px-3 py-1 text-xs font-bold"
            style={profile.familySuddenCardiacDeath ? { background: "var(--dz-alert-red)", color: "#fff" } : { background: "#e6ebe6", color: "var(--dz-sub)" }}>
            {profile.familySuddenCardiacDeath ? t("guardian.profile.yes") : t("guardian.profile.no")}
          </span>
        </button>
      </Card>

      {/* 紧急联系人 */}
      <Card el="profile-contacts">
        <CardHead title={t("guardian.profile.contacts")} editing={editContacts} onToggle={() => setEditContacts((v) => !v)} el="profile-contacts-edit" />
        <div className="mt-3 grid gap-2.5">
          {profile.contacts.map((c, i) => (
            <div key={c.id}>
            <div className="flex items-center gap-3 rounded-[12px] p-3" style={{ background: "#f4f6f3", border: "1px solid var(--dz-line)" }}>
              <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full text-sm font-extrabold text-white" style={{ background: "var(--dz-orange)" }}>{c.rank}</span>
              <div className="min-w-0 flex-1">
                <div className="truncate font-bold" style={{ color: "var(--dz-ink)" }}>{c.name}</div>
                <div className="text-xs" style={{ color: "var(--dz-sub)" }}>{c.phone} · {t(c.relationshipKey)}</div>
              </div>
              {editContacts ? (
                <>
                  {i > 0 && (
                    <button data-el="contact-move-up" aria-label={t("guardian.profile.moveUp")}
                      onClick={() => {
                        const arr = [...profile.contacts];
                        [arr[i - 1], arr[i]] = [arr[i], arr[i - 1]];
                        updateProfile({ contacts: arr.map((x, idx) => ({ ...x, rank: idx + 1 })) });
                      }}
                      className="grid h-8 w-8 place-items-center rounded-full" style={{ background: "#e6ebe6", color: "var(--dz-ink)" }}>
                      <ArrowUp size={15} />
                    </button>
                  )}
                  <button data-el="contact-edit" aria-label={t("guardian.profile.editContact")}
                    onClick={() => setEditing((cur) => (cur === c.id ? null : c.id))}
                    className="grid h-8 w-8 place-items-center rounded-full"
                    style={{ background: editing === c.id ? "var(--dz-ink)" : "var(--dz-orange)", color: "#fff" }}>
                    <Pencil size={14} />
                  </button>
                </>
              ) : (
                <a href={`tel:${c.phone}`} data-el="contact-call" className="grid h-9 w-9 place-items-center rounded-full transition-transform active:scale-90" style={{ background: "#eef4ee" }}>
                  <Phone size={17} style={{ color: "var(--dz-ok)" }} />
                </a>
              )}
            </div>
            {editContacts && editing === c.id && (
              <ContactInlineEditor
                contact={c}
                onSave={(nc) => {
                  updateProfile({ contacts: profile.contacts.map((x) => (x.id === nc.id ? nc : x)) });
                  setEditing(null);
                }}
                onCancel={() => setEditing(null)}
              />
            )}
            </div>
          ))}
        </div>
      </Card>

      <button data-el="profile-save"
        onClick={() => { setEditBasic(false); setEditContacts(false); setEditing(null); toast.success(t("guardian.profile.saved")); }}
        className="mt-5 w-full rounded-full px-5 py-3.5 text-base font-extrabold text-white transition-transform active:scale-[.985]"
        style={{ background: "var(--dz-orange)" }}>
        {t("guardian.profile.save")}
      </button>

      {healthOpen && (
        <HealthPickerSheet options={HEALTH_STATUS_KEYS} value={profile.healthStatusKey}
          onPick={(v) => updateProfile({ healthStatusKey: v })} onClose={() => setHealthOpen(false)} />
      )}
      {diseaseOpen && (
        <DiseasePickerSheet options={DISEASE_KEYS} values={profile.diseaseKeys}
          onToggle={toggleDisease} onClose={() => setDiseaseOpen(false)} />
      )}
    </AppShell>
  );
}
