"use client";

// 极简线性底部导航（设计同学视觉）：日常 / 数据 / 档案
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useTranslation } from "react-i18next";
import { Home, BarChart3, User } from "lucide-react";

const TABS = [
  { href: "/daily", key: "daily", icon: Home, el: "nav-daily" },
  { href: "/data", key: "data", icon: BarChart3, el: "nav-data" },
  { href: "/profile", key: "profile", icon: User, el: "nav-profile" },
];

export function BottomNav() {
  const pathname = usePathname();
  const { t } = useTranslation();
  return (
    <nav
      data-el="bottom-nav"
      className="fixed inset-x-0 bottom-0 z-30 mx-auto w-full max-w-[460px]"
      style={{
        background: "#ffffff",
        borderTop: "1px solid var(--dz-line)",
        paddingBottom: "max(10px, env(safe-area-inset-bottom, 0px))",
      }}
    >
      <div className="grid grid-cols-3">
        {TABS.map((tab) => {
          const active = pathname === tab.href;
          const Icon = tab.icon;
          return (
            <Link
              key={tab.href}
              href={tab.href}
              data-el={tab.el}
              className="flex flex-col items-center gap-1 py-2.5 text-[11px] font-semibold transition-transform active:scale-95"
              style={{ color: active ? "var(--dz-orange)" : "var(--dz-sub)" }}
            >
              <Icon size={22} strokeWidth={active ? 2.4 : 2} />
              {t(`guardian.nav.${tab.key}`)}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
