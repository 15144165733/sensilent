// 简洁线性品牌图标与场景/时间线图标（统一 stroke 风格，替代 emoji）
import type { SVGProps } from "react";

/** 鹅在 · 品牌标志：简洁线性鹅头轮廓 */
export function GooseMark({ size = 24, ...props }: { size?: number } & SVGProps<SVGSVGElement>) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" {...props}>
      {/* 头部 */}
      <path d="M9 4.2a3.2 3.2 0 0 1 3.2 3.2v3.1" />
      {/* 颈到身体 */}
      <path d="M12.2 10.5c0 3.4-2.6 4.4-2.6 6.7A3.4 3.4 0 0 0 13 20.4h1.2a5 5 0 0 0 5-5c0-1.4-.5-2.4-1.3-3.2" />
      {/* 喙 */}
      <path d="M9 6.1 6.3 6.9l2.4 1.2" />
      {/* 眼 */}
      <circle cx="10.4" cy="6.4" r="0.5" fill="currentColor" stroke="none" />
    </svg>
  );
}
