"use client";

// 档案页用的软糖风底部弹窗：单选（健康状态）/ 多选（病史）/ 联系人编辑
import { useState, type ReactNode } from "react";
import { X, Check } from "lucide-react";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";
import { CONTACT_REL_KEYS } from "@/lib/guardian/data";
import type { EmergencyContact } from "@/lib/guardian/types";

function Sheet({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  const { t } = useTranslation();
  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center"
      style={{ background: "rgba(52,65,60,.4)", backdropFilter: "blur(2px)" }}
      onClick={onClose}
      data-el="sheet-overlay"
    >
      <div
        className="max-h-[85vh] w-full max-w-[460px] overflow-y-auto rounded-t-[20px] p-6"
        style={{ background: "#fff", boxShadow: "0 -18px 40px rgba(0,0,0,.12)", paddingBottom: "calc(96px + env(safe-area-inset-bottom,0px))" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-xl font-extrabold" style={{ color: "var(--dz-ink)" }}>{title}</h2>
          <button aria-label={t("guardian.settings.close")} onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full" style={{ background: "#f4f6f3", color: "var(--dz-ink)" }}>
            <X size={16} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

/** 单选：健康状态 */
export function HealthPickerSheet({
  options,
  value,
  onPick,
  onClose,
}: {
  options: readonly string[];
  value: string;
  onPick: (v: string) => void;
  onClose: () => void;
}) {
  const { t } = useTranslation();
  return (
    <Sheet title={t("guardian.profile.healthPick")} onClose={onClose}>
      <div className="grid gap-2.5">
        {options.map((k) => {
          const active = k === value;
          return (
            <button
              key={k}
              data-el={`health-opt-${k}`}
              onClick={() => {
                onPick(k);
                onClose();
              }}
              className="flex items-center justify-between rounded-[12px] px-4 py-3.5 text-left transition-colors"
              style={active
                ? { background: "var(--dz-orange)", color: "#fff" }
                : { background: "#f4f6f3", color: "var(--dz-ink)", border: "1px solid var(--dz-line)" }}
            >
              <span>
                <span className="block font-extrabold">{t(`guardian.health.${k}`)}</span>
                <span className="mt-0.5 block text-xs" style={{ opacity: 0.75 }}>{t(`guardian.health.${k}_desc`)}</span>
              </span>
              {active && <Check size={18} className="shrink-0" />}
            </button>
          );
        })}
      </div>
    </Sheet>
  );
}

/** 多选：病史 */
export function DiseasePickerSheet({
  options,
  values,
  onToggle,
  onClose,
}: {
  options: readonly string[];
  values: string[];
  onToggle: (v: string) => void;
  onClose: () => void;
}) {
  const { t } = useTranslation();
  return (
    <Sheet title={t("guardian.profile.diseaseTitle")} onClose={onClose}>
      <div className="grid grid-cols-2 gap-2.5">
        {options.map((k) => {
          const active = values.includes(k);
          return (
            <button
              key={k}
              data-el={`disease-opt-${k}`}
              onClick={() => onToggle(k)}
              className="flex items-center justify-between rounded-[18px] px-3.5 py-3 text-left text-sm font-bold transition-transform active:scale-[.97]"
              style={active
                ? { background: "var(--dz-orange)", color: "#fff" }
                : { background: "#f4f6f3", color: "var(--dz-ink)", border: "1px solid var(--dz-line)" }}
            >
              {t(`guardian.disease.${k}`)}
              {active && <Check size={15} className="shrink-0" />}
            </button>
          );
        })}
      </div>
    </Sheet>
  );
}

/** 联系人编辑：姓名 / 电话 / 关系。三段式布局：标题固定、内容可滚动、保存按钮固定底部，避免被键盘/导航栏遮挡。 */
/** 联系人内联编辑：点卡片「编辑」后在卡片下方原地展开，随页面滚动，保存按钮不会被键盘/导航栏遮挡。 */
export function ContactInlineEditor({
  contact,
  onSave,
  onCancel,
}: {
  contact: EmergencyContact;
  onSave: (c: EmergencyContact) => void;
  onCancel: () => void;
}) {
  const { t } = useTranslation();
  const [name, setName] = useState(contact.name);
  const [phone, setPhone] = useState(contact.phone);
  const [rel, setRel] = useState(contact.relationshipKey);

  return (
    <div
      data-el="contact-inline-editor"
      className="mt-2 grid gap-3 rounded-[12px] p-4"
      style={{ background: "#f4f6f3", border: "1px solid var(--dz-line)" }}
    >
      <label className="grid gap-1.5">
        <span className="text-xs font-bold" style={{ color: "rgba(52,65,60,.6)" }}>{t("guardian.profile.field.contactName")}</span>
        <input data-el="contact-name-input" value={name} onChange={(e) => setName(e.target.value)}
          className="rounded-[14px] bg-white px-3.5 py-2.5 text-sm outline-none" style={{ border: "1px solid rgba(52,65,60,.12)" }} />
      </label>
      <label className="grid gap-1.5">
        <span className="text-xs font-bold" style={{ color: "rgba(52,65,60,.6)" }}>{t("guardian.profile.field.phone")}</span>
        <input data-el="contact-phone-input" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)}
          className="rounded-[14px] bg-white px-3.5 py-2.5 text-sm outline-none" style={{ border: "1px solid rgba(52,65,60,.12)" }} />
      </label>
      <div className="grid gap-1.5">
        <span className="text-xs font-bold" style={{ color: "rgba(52,65,60,.6)" }}>{t("guardian.profile.field.contactRel")}</span>
        <div className="flex flex-wrap gap-2">
          {CONTACT_REL_KEYS.map((k) => {
            const key = `guardian.contactRel.${k}`;
            const active = rel === key;
            return (
              <button key={k} data-el={`contact-rel-${k}`} onClick={() => setRel(key)}
                className="rounded-full px-3 py-1.5 text-xs font-bold transition-transform active:scale-95"
                style={active
                  ? { background: "var(--dz-ink)", color: "#fff" }
                  : { background: "#f4f6f3", color: "var(--dz-ink)", border: "1px solid var(--dz-line)" }}>
                {t(key)}
              </button>
            );
          })}
        </div>
      </div>

      {/* 保存 / 取消：就在卡片内，随内容一起，不会被遮挡 */}
      <div className="mt-1 flex gap-2.5">
        <button
          data-el="contact-cancel"
          onClick={onCancel}
          className="rounded-[18px] px-4 py-3 text-sm font-bold transition-transform active:scale-[.98]"
          style={{ background: "#f4f6f3", color: "var(--dz-ink)", border: "1px solid var(--dz-line)" }}
        >
          {t("guardian.settings.close")}
        </button>
        <button
          data-el="contact-save"
          onClick={() => {
            onSave({ ...contact, name: name.trim() || contact.name, phone: phone.trim() || contact.phone, relationshipKey: rel });
            toast.success(t("guardian.profile.contactSaved"));
          }}
          className="flex-1 rounded-[18px] py-3 font-heading text-sm font-extrabold text-white transition-transform active:scale-[.98]"
          style={{ background: "var(--dz-orange)" }}
        >
          {t("guardian.profile.save")}
        </button>
      </div>
    </div>
  );
}
