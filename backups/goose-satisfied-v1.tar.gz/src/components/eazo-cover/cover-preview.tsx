"use client";

// Eazo 封面预览：自主循环演示核心交互——平安态呼吸徽章 → 触发跌倒告警 → 返回平安。
// 完全自包含，不导入产品 store / auth / API，使用本地 COVER_PREVIEW_DATA。
import { useEffect, useState } from "react";

const COVER_PREVIEW_DATA = {
  brand: "鹅在",
  elder: "李奶奶",
  location: "客厅",
  safe: { label: "一切平安", breath: 14 },
  alert: { label: "疑似跌倒", breath: 9 },
};

type Phase = "safe" | "alert";

export function CoverPreview() {
  const [phase, setPhase] = useState<Phase>("safe");

  useEffect(() => {
    const seq = setInterval(() => {
      setPhase((p) => (p === "safe" ? "alert" : "safe"));
    }, 2200);
    return () => clearInterval(seq);
  }, []);

  const isAlert = phase === "alert";
  const d = isAlert ? COVER_PREVIEW_DATA.alert : COVER_PREVIEW_DATA.safe;

  return (
    <div
      className="grid h-full w-full place-items-center overflow-hidden"
      style={{
        background: isAlert
          ? "radial-gradient(circle at 50% 30%, rgba(216,88,77,.95), #34413c 100%)"
          : "radial-gradient(circle at 20% 12%,rgba(233,130,67,.2),transparent 28%),linear-gradient(180deg,#fff7ea,#faf3e3 60%,#f6ead7)",
        transition: "background 700ms ease",
        color: isAlert ? "#faf3e3" : "#34413c",
        fontFamily: '"Noto Sans SC", system-ui, sans-serif',
      }}
    >
      <div className="flex w-full max-w-[360px] flex-col items-center px-6 text-center">
        <div className="mb-5 text-sm font-extrabold tracking-wide opacity-90">
          🪿 {COVER_PREVIEW_DATA.brand}
        </div>

        {/* 呼吸徽章 */}
        <div
          className="grid h-[128px] w-[128px] place-items-center"
          style={{
            borderRadius: "46% 54% 50% 50%",
            background: isAlert
              ? "linear-gradient(145deg,#eda49b,#d8584d)"
              : "linear-gradient(145deg,#d8eee3,#a9d0c1)",
            boxShadow:
              "inset 0 14px 18px rgba(255,255,255,.7), inset 0 -18px 24px rgba(69,117,98,.18),0 22px 38px rgba(91,139,118,.23)",
            animation: `wg-breathe ${isAlert ? "1s" : "3.4s"} ease-in-out infinite`,
            transition: "background 500ms ease",
          }}
        >
          <strong
            className="text-[44px] leading-none text-white"
            style={{ fontFamily: '"Baloo 2", sans-serif', textShadow: "0 3px 8px rgba(52,65,60,.16)" }}
          >
            {isAlert ? "急" : "安"}
          </strong>
        </div>

        <h1 className="mt-5 text-[26px] font-extrabold leading-tight" style={{ fontFamily: '"Baloo 2", sans-serif' }}>
          {isAlert ? `${COVER_PREVIEW_DATA.elder}可能摔倒了` : `${COVER_PREVIEW_DATA.elder}今天很好`}
        </h1>
        <p className="mt-1 text-sm opacity-85">
          {COVER_PREVIEW_DATA.location} · 呼吸 {d.breath} 次/分 · {d.label}
        </p>

        {/* 呼吸脉动线 */}
        <svg className="mt-4 h-8 w-[150px]" viewBox="0 0 160 40" aria-hidden>
          <path
            d="M5 24 C25 24 25 12 42 12 S61 30 78 22 S100 8 115 18 S130 25 155 16"
            fill="none"
            stroke={isAlert ? "#ffd9d2" : "#E98243"}
            strokeWidth="6"
            strokeLinecap="round"
          />
        </svg>
      </div>
    </div>
  );
}
