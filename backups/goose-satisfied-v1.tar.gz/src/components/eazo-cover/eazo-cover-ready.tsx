"use client";

// 标记封面预览已就绪（供平台截图服务识别）。仅用于 /eazo-cover-preview。
import { useEffect, type ReactNode } from "react";

export function EazoCoverReady({ children }: { children: ReactNode }) {
  useEffect(() => {
    document.body.setAttribute("data-eazo-cover-ready", "1");
    return () => {
      document.body.removeAttribute("data-eazo-cover-ready");
    };
  }, []);
  return <>{children}</>;
}
